# Chromium
Chromium permette di usare chrome con phpupheter

## Dipendenze
nesk/puphpeteer