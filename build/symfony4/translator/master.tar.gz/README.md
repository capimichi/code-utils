# Translator

## Dipendenze
Translator dipende dal pacchetto "symfony4/chromium"